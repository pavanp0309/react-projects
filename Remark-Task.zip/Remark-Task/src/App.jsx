import React from 'react'
import RemarkList from './components/RemarkList'

const App = () => {
  return (
   <>
   <RemarkList/>
   </>
  )
}

export default App
